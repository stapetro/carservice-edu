------------------------------------------------------------------------
Description of external libraries:
------------------------------------------------------------------------

AjaxControlToolkit.Binary.NET4.zip	http://ajaxcontroltoolkit.codeplex.com/releases/view/43475#DownloadId=116534

------------------------------------------------------------------------
author: 
Stanislav Petrov
------------------------------------------------------------------------
